# Webアプリケーション開発 II

## Laravel + Homestead Template

````
$ laravel new oic_2017_2
$ composer install 
$ composer require laravel/homestead --dev
$ vagrant up
````